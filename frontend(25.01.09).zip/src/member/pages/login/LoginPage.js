import React from "react";
import LoginComponent from "../../component/LoginComponent";

const LoginPage = () => {
  return (
    <div>
      <LoginComponent />
    </div>
  );
};

export default LoginPage;

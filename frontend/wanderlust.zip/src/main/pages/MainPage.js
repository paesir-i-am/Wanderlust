import React from "react";

const Home = () => {
  return (
    <div>
      <h1>홈 페이지</h1>
      <p>여행에 대한 갈망을 해결하세요!</p>
    </div>
  );
};

export default Home;

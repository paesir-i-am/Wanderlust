package com.wanderlust.member.entity;

/*
 * Description    :
 * ProjectName    : wanderlust
 * PackageName    : com.wanderlust.member.entity
 * FileName       : MemberRole
 * Author         : paesir
 * Date           : 24. 12. 16.
 * ===========================================================
 * DATE                  AUTHOR       NOTE
 * -----------------------------------------------------------
 * 24. 12. 16.오후 2:23  paesir      최초 생성
 */


public enum MemberRole {
  USER,ADMIN
}
